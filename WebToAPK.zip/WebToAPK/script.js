/*
==================================================
 ELEMENTS
==================================================
*/
const website      = document.getElementById("website");
const appName       = document.getElementById("appName");
const packageName   = document.getElementById("packageName");
const ghOwner        = document.getElementById("ghOwner");
const ghRepo         = document.getElementById("ghRepo");
const ghBranch       = document.getElementById("ghBranch");
const ghToken        = document.getElementById("ghToken");

const generateBtn   = document.getElementById("generateBtn");
const buildBtn       = document.getElementById("buildBtn");
const actions        = document.getElementById("actions");
const status          = document.getElementById("status");
const preview         = document.getElementById("preview");
const previewUrl      = document.getElementById("previewUrl");
const previewApp      = document.getElementById("previewApp");
const previewPackage  = document.getElementById("previewPackage");
const progress        = document.getElementById("progress");
const progressBar     = document.getElementById("progressBar");

const WORKFLOW_FILE = "build-apk.yml";

let config = null;

/*
==================================================
 GENERATE
==================================================
*/
generateBtn.addEventListener("click", generateConfiguration);

function generateConfiguration(){
  const url = website.value.trim();
  const name = appName.value.trim();
  const pkg = packageName.value.trim();

  let parsedUrl;
  try{
    parsedUrl = new URL(url);
  }catch{
    showStatus("❌ Please enter a valid website URL.", true);
    return;
  }

  if(parsedUrl.protocol !== "https:" && parsedUrl.protocol !== "http:"){
    showStatus("❌ Only HTTP/HTTPS URLs are supported.", true);
    return;
  }

  const finalName = name || "My Web App";

  const packageRegex = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;
  if(!packageRegex.test(pkg)){
    showStatus("❌ Invalid Android package name (e.g. com.example.app).", true);
    return;
  }

  config = { website:url, appName:finalName, packageName:pkg };

  previewUrl.textContent = config.website;
  previewApp.textContent = config.appName;
  previewPackage.textContent = config.packageName;

  preview.style.display = "block";
  actions.style.display = "block";

  showStatus("✅ Configuration ready. Press Build APK.");
}

/*
==================================================
 BUILD APK — triggers the real GitHub Actions run
 and follows it through to the finished artifact.
 No local zip step; GitHub itself always wraps
 downloaded artifacts in a .zip container — that is
 a GitHub platform behavior, not something this page
 can change — but the zip will contain only the one
 debug APK.
==================================================
*/
buildBtn.addEventListener("click", buildAPK);

async function buildAPK(){
  if(!config){
    showStatus("Generate the configuration first.", true);
    return;
  }

  const owner = ghOwner.value.trim();
  const repo = ghRepo.value.trim();
  const branch = ghBranch.value.trim() || "main";
  const token = ghToken.value.trim();

  if(!owner || !repo){
    showStatus("⚠️ Enter your GitHub username and repository.", true);
    return;
  }
  if(!token){
    showStatus("⚠️ Enter a GitHub token with Actions read/write access.", true);
    return;
  }

  buildBtn.disabled = true;
  progress.style.display = "block";
  progressBar.style.width = "8%";

  const api = `https://api.github.com/repos/${owner}/${repo}`;
  const headers = {
    "Authorization": `Bearer ${token}`,
    "Accept": "application/vnd.github+json",
    "Content-Type": "application/json"
  };

  try{
    showStatus("🚀 Triggering GitHub Actions workflow...");

    const dispatchedAt = new Date();

    const dispatchRes = await fetch(
      `${api}/actions/workflows/${WORKFLOW_FILE}/dispatches`,
      {
        method:"POST",
        headers,
        body: JSON.stringify({
          ref: branch,
          inputs:{
            website_url: config.website,
            app_name: config.appName,
            package_name: config.packageName
          }
        })
      }
    );

    if(!dispatchRes.ok){
      const detail = await safeErrorText(dispatchRes);
      throw new Error(`Could not start the workflow (${dispatchRes.status}). ${detail}`);
    }

    progressBar.style.width = "20%";
    showStatus("⏳ Waiting for the run to appear...");

    const run = await findNewRun(api, headers, branch, dispatchedAt);
    progressBar.style.width = "35%";

    showStatus(`⏳ Build running (run #${run.run_number})...`);
    const finishedRun = await pollRunUntilComplete(api, headers, run.id);

    if(finishedRun.conclusion !== "success"){
      progressBar.style.width = "100%";
      showStatus(
        `❌ Build finished with status "${finishedRun.conclusion}". Open the run to see logs.`,
        true
      );
      linkToRun(finishedRun.html_url);
      return;
    }

    progressBar.style.width = "90%";
    showStatus("📦 Fetching the built APK...");

    const artifact = await findApkArtifact(api, headers, finishedRun.id);
    progressBar.style.width = "100%";

    if(artifact){
      showStatus("✅ Build succeeded. Open the artifact below to download the debug APK.");
      linkToRun(artifact.htmlUrl, "Download debug APK");
    }else{
      showStatus("✅ Build succeeded, but no artifact was found on the run page.");
      linkToRun(finishedRun.html_url);
    }

  }catch(err){
    progressBar.style.width = "100%";
    showStatus(`❌ ${err.message}`, true);
  }finally{
    buildBtn.disabled = false;
  }
}

/*
Find the run created by this dispatch (workflow_dispatch runs
don't return an id directly from the trigger call, so poll the
run list briefly for the newest matching run).
*/
async function findNewRun(api, headers, branch, dispatchedAt, attempts=10){
  for(let i=0;i<attempts;i++){
    await sleep(1500);

    const res = await fetch(
      `${api}/actions/workflows/${WORKFLOW_FILE}/runs?branch=${encodeURIComponent(branch)}&event=workflow_dispatch&per_page=5`,
      { headers }
    );

    if(res.ok){
      const data = await res.json();
      const match = (data.workflow_runs || []).find(
        r => new Date(r.created_at) >= dispatchedAt
      );
      if(match) return match;
    }
  }
  throw new Error("Timed out waiting for the run to start. Check the Actions tab on GitHub.");
}

async function pollRunUntilComplete(api, headers, runId, maxAttempts=200){
  for(let i=0;i<maxAttempts;i++){
    const res = await fetch(`${api}/actions/runs/${runId}`, { headers });
    if(!res.ok){
      throw new Error(`Could not read run status (${res.status}).`);
    }
    const run = await res.json();
    if(run.status === "completed"){
      return run;
    }
    progressBar.style.width = `${35 + Math.min(i, 50)}%`;
    await sleep(5000);
  }
  throw new Error("Timed out waiting for the build to finish. Check the Actions tab on GitHub.");
}

async function findApkArtifact(api, headers, runId){
  const res = await fetch(`${api}/actions/runs/${runId}/artifacts`, { headers });
  if(!res.ok) return null;
  const data = await res.json();
  const artifact = (data.artifacts || [])[0];
  if(!artifact) return null;
  return {
    name: artifact.name,
    htmlUrl: artifact.archive_download_url.replace("api.github.com/repos", "github.com").replace("/zip", "")
  };
}

/*
==================================================
 STATUS / LINK HELPERS
==================================================
*/
function showStatus(message, error=false){
  status.textContent = message;
  status.style.color = error ? "#ff6b6b" : "#62dcff";
}

function linkToRun(url, label="Open on GitHub"){
  const a = document.createElement("a");
  a.href = url;
  a.target = "_blank";
  a.rel = "noopener";
  a.textContent = " " + label;
  status.appendChild(a);
}

async function safeErrorText(res){
  try{
    const data = await res.json();
    return data.message || "";
  }catch{
    return "";
  }
}

function sleep(ms){
  return new Promise(resolve => setTimeout(resolve, ms));
}

/*
==================================================
 ENTER KEY
==================================================
*/
website.addEventListener("keydown", event => {
  if(event.key === "Enter"){
    generateConfiguration();
  }
});
