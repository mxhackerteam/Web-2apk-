# Web2APK

Turns a website URL into a minimal Android WebView app, built automatically by GitHub Actions when you press **Build APK** on `index.html` — no manual "Run workflow" click, no local zip step.

## What changed from the original draft

The original page only opened the GitHub Actions page and left a human to press "Run workflow" by hand, and it saved the config to `localStorage` for a workflow that never read it. That's fixed:

- `script.js` now calls the GitHub REST API directly: it triggers `workflow_dispatch` with your website URL, app name and package name as real inputs, then polls the run until it finishes and links you to the artifact.
- `build-apk.yml` actually builds something: it stamps `android-template/` with your inputs and runs `gradle assembleDebug`.
- The old "download a zip" idea is gone from the page. One caveat that can't be engineered away: **GitHub always wraps a downloaded Actions artifact in a `.zip`**, even a single file — that's how the GitHub artifact API and web UI work, not a bug in this project. The zip you get from the link this page gives you contains exactly one file: `app-debug.apk`.

## One-time setup

1. Create a GitHub repo (or use an existing one) and push everything in this folder to it, keeping the folder structure:
   ```
   index.html
   style.css
   script.js
   .github/workflows/build-apk.yml
   android-template/...
   ```
2. Create a GitHub Personal Access Token with the **Actions: Read and write** permission (fine-grained token scoped to just this repo is enough). You'll paste this into the page each time you build — it isn't stored anywhere.
3. Open `index.html` locally, or enable GitHub Pages for the repo and open it there.

## Using it

1. Fill in the website URL, app name, and package name, then **Generate APK Configuration**.
2. Fill in your GitHub username, repo name, branch (default `main`), and the token from step 2 above.
3. Press **Build APK**. The page triggers the workflow, watches it run, and gives you a link to the finished `Web2APK-debug` artifact when it's done — typically 2–4 minutes.

## Notes on the generated app

- The app is a single-Activity `WebView` shell (`MainActivity.java`) that loads your URL live — it does not bundle a static copy of the site, so it always reflects the current site.
- It's a **debug** build, unsigned beyond the default debug key, meant for installing on a test device — not for the Play Store.
- `android-template/` uses `{{WEBSITE_URL}}`, `{{APP_NAME}}`, `{{PACKAGE_NAME}}` placeholders; the workflow substitutes them and moves `MainActivity.java` into the correct package folder before building.
